#!/usr/bin/perl

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - H E A D E R - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# MANUAL FOR insert_results.pl

=pod

=head1 NAME

$0 -- Insert results from tophat and cufflinks analysis into the mysql database : PENGUIN

=head1 SYNOPSIS

insert_results.pl --in FOLDER [--help] [--manual]

=head1 DESCRIPTION

Accepts the folders containing the output from "top_cuff_analysis.pl"
 
=head1 OPTIONS

=over 3

=item B<-i, -1, -a, --in, --folder>=FOLDER

Results folder (e.g. the folder with results to insert into the database).  (Required)

=item B<-h, --help>

Displays the usage message.  (Optional) 

=item B<-man, --manual>

Displays full manual.  (Optional) 

=back

=head1 DEPENDENCIES

Requires the following Perl libraries (all standard in most Perl installs).
   DBI
   DBD::mysql
   Getopt::Long
   Pod::Usage

=head1 AUTHOR

Written by Modupe Adetunji, 
Center for Bioinformatics and Computational Biology Core Facility, University of Delaware.

=head1 REPORTING BUGS

Report bugs to amodupe@udel.edu

=head1 COPYRIGHT

Copyright 2013 MOA.  
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>.  
This is free software: you are free to change and redistribute it.  
There is NO WARRANTY, to the extent permitted by law.  

Please acknowledge author and affiliation in published work arising from this script's 
usage <http://bioinformatics.udel.edu/Core/Acknowledge>.

=cut

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - U S E R  V A R I A B L E S- - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# CODE FOR insert_results.pl

use strict;
use DBI;
use DBD::mysql;
use Getopt::Long;
use Pod::Usage;

#ARGUMENTS
my($in1,$help,$manual);
GetOptions (	
				"i|1|a|in|folder=s"	=>	\$in1,
                                "h|help"        =>      \$help,
                                "man|manual"	=>      \$manual );

# VALIDATE ARGS
pod2usage( -verbose => 2 )  if ($manual);
pod2usage( -verbose => 1 )  if ($help);
pod2usage( -msg  => "ERROR!  Required argument -1 (input folder) not found. \n", -exitval => 2, -verbose => 1)  if (! $in1 );

#making sure the input file is parsable
my @temp = split('',$in1); $in1 = undef; my $checking = pop(@temp); push (@temp, $checking); unless($checking eq "/"){ push (@temp,"/")}; foreach(@temp){$in1 .= $_};

# DATABASE ATTRIBUTES
my $dsn = 'dbi:mysql:PENGUIN';
my $user = 'modupe';
my $passwd = 'penguin123';

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - G L O B A L  V A R I A B L E S- - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# FOLDER VARIABLES
my ($top_folder, $cuff_folder);

# RESULTS_HASH
my %Hashresults; my $number=0;

# DATABASE VARIABLES
my ($dbh, $sth, $syntax, $row, @row);

#PARSING VARIABLES
my @parse; my $len;

# TABLE VARIABLES
my ($lib_id, $total, $mapped, $unmapped, $deletions, $insertions, $junctions, $genes, $isoforms, $prep, $date); #RESULTS_SUMMARY TABLE
my ($raw_reads, $fastqc, $accepted, $unmapped_bam, $deletions_bed, $insertions_bed, $junctions_bed, $skipped_gtf, $transcripts_gtf, $isoforms_fpkm, $genes_fpkm, $run_log); #ACTUAL_FILES TABLE
my ($track, $class, $ref_id, $gene, $gene_name, $tss, $locus, $chrom_no, $chrom_start, $chrom_stop, $length, $coverage, $fpkm, $fpkm_low, $fpkm_high, $fpkm_stat); # GENES_FPKM & ISOFORMS_FPKM TABLE

#GETTING ACCURATE FILE PATHS
system `locate $in1 > parse.txt`;
my $filelocation = `head -n1 parse.txt`; @parse = split('\/', $filelocation); $in1 = undef; $len =$#parse-1;foreach(0..$len){$in1 .= $parse[$_]."\/";};
system `rm -f parse.txt`;

#OPENING FOLDER
opendir(DIR,$in1) or die "Folder \"$in1\" doesn't exist\n";
my @Directory = readdir(DIR);
close(DIR);
my $counting=0;
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - M A I N - - - - - - - - - - - - - - - - - - - - - -
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# CONNECT TO THE DATABASE
print "\n\n\tCONNECTING TO THE DATABASE : $dsn\n\n";
$dbh = DBI->connect($dsn, $user, $passwd) or die "Connection Error: $DBI::errstr\n";

#CHECKING THE LIBRARIES ALREADY IN THE DATABASE
$syntax = "select library_id from RESULTS_SUMMARY";
$sth = $dbh->prepare($syntax);
$sth->execute or die "SQL Error: $DBI::errstr\n";
while ($row = $sth->fetchrow_array() ) {
        $Hashresults{$row} = $number; $number++;
}
# EACH FOLDER
foreach my $FOLDER (@Directory ){ 
	if ($FOLDER =~ /^library_(.*)$/){
        	if (exists $Hashresults{$1}){ ##print "\n$1\n";die;
			$lib_id = $1;
        		print "\n. . .\n\tWORKING ON LIBRARY-$1\n\n";
        		$fastqc = `ls /home/TANALYSIS/fastqc_out/library_$1/*zip`; if (length $fastqc < 1){print "\tFASTQC file doesn't exist\t==>"; next; print "\tSkipping library_$1!!\n\n";} #ACTUAL_FILES table


# UPDATE FASTQChtml column in DATABASE : PENGUIN
	        	#ACTUAL_FILES table
			print ". . .\n\tINSERTING INTO THE DATABASE IN \"ACTUAL_FILES\" TABLE\n\n";
         	        $sth = $dbh->prepare("update ACTUAL_FILES set FASTQC_html='$fastqc' where library_id = ?");
                	$sth ->execute( $lib_id );
        	$counting++;}
	}
}
# DISCONNECT FROM THE DATABASE
print "\n\tCOMMITING and DISCONNECTING FROM THE DATABASE : $dsn\n\n";
$dbh->commit;
$dbh->disconnect();

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
print "\n$number\t\t$counting\n\n*********DONE*********\n\n";
# - - - - - - - - - - - - - - - - - - EOF - - - - - - - - - - - - - - - - - - - - - -
exit;
